#!/bin/bash

sudo cp run /usr/local/bin/run

sudo chmod +x /usr/local/bin/run

echo "Run Installed Successfully"